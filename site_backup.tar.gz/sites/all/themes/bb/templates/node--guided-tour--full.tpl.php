<div id="tour-content">
	<div class="content"><?php print $slides; ?></div>
</div>

<div id="last-slide"><</div>
<div id="next-slide">></div>