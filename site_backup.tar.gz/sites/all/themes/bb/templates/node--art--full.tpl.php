<div class="art-full">
	
	<div class="header">
		<h1><?php print $title; ?></h1>
	</div>

	<div class="main-image"><div class="image"> <?php print $main_image; ?></div></div>
	<div class="art-info"><?php print $size; ?> <span class="bull">&bull;</span> <?php print $medium; ?></div>
	<div class="body"><?php print $body; ?></div>
	<div class="devider">&bull;&bull;&bull;</div>
	<div id="purchase">
		<div class="header">
			<h2>Purchase Print</h2>
			<p class="center">...coming soon...</p>
		</div>

	</div>
</div>