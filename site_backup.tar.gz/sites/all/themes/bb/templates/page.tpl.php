<div id="wrapper">
	
	<div id="header">
		<div id="header-inner" class="clearfix">
			<div id="logo"><a href="/blog_base">Blog Base</a></div>
			<div class="menu-toggle">Menu</div>
			<div id="nav"><?php print render($page['nav_main']); ?></div> 
		</div>
	</div>
	
	<div id="main-content">
		
		<div id="main">
			<div id="main-inner">
				<div id="content">
					<?php if($title): ?>
						<h1><?php echo $title; ?></h1>
					<?php endif; ?>
					
					<?php echo render($page['content']); ?>
				</div>
			</div>
		</div>
		
		<?php if($page['sidebar_first']): ?> 
			<div id="side">
				<div id="side-inner">
					<div id="content"><?php echo render($page['sidebar_first']); ?></div>
				</div>
			</div>
		<?php endif; ?>
	</div>

</div>

<div id="footer">
	<div id="footer-iner">
		<div id="copy">&copy; <?php echo date('Y'); ?> Don't steal. It's not nice.</div>
	</div>
</div>
