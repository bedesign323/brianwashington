<div id="wrapper">
	
	<div id="header">
		<div id="header-inner" class="clearfix">
			<div id="logo"><a href="/welcome"><span>The Artwork of</span>Brian Washington </a></div>
			
		</div>
	</div>
	
	<div id="main-content">
		
		<div id="main">
			<div id="main-inner">
				<div id="content">
					
					<h1>The Continual Struggle</h1>
					<div id="enter"><a href="/welcome" class="btn">Enter</a></div>

					<div class="images">
						<div class="image-1 image-holder"><div class="image"></div></div>
						<div class="image-2 image-holder"><div class="image"></div></div>
						<div class="image-3 image-holder"><div class="image"></div></div>
					</div>
					
					
				</div>
			</div>
		</div>
		
	</div>

</div>
