<div class="art-teaser">
	
	<div class="main-image"><?php print $main_image; ?></div>
	<div class="caption"><?php print $title; ?></div>
	
</div>