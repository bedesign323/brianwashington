<div class="tour-slide slide">
	<div class="body"><?php print $body; ?></div>
	
</div>