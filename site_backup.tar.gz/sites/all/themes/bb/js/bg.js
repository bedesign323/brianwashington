
Drupal.behaviors.bg = {
	attach: function (context, settings) {
		
		// var index = 0;
		// var settings = Drupal.settings.gallery_settings;
		// console.log(settings);
		// var images = settings.images;
		
		// var last_index = 0;
		
		// var start_show = setInterval(function() {
	 //    	nextImage();
	 //  	}, 5000);

		// jQuery(images).each(function(){
		// 	jQuery("<img/>")[0].src = this;
		// });

		// function nextImage(){
		// 	last_index = index;
		//   	index = (index >= images.length - 1) ? 0 : index + 1;
		//     jQuery.backstretch(images[index]);	    
		// }
		  
		// jQuery('body').click(function(){
		// 	clearInterval(start_show);
		//   	nextImage();
		//   //	return false;
		// });
		
		// setTimeout(function(){jQuery.backstretch(images[index], {speed: 1000})}, 1000);


		// jQuery('#header').css('bottom', -200).delay(1500).animate({'bottom': 0}, 1500);
		// jQuery('#header-bg').css('bottom', -300).delay(1500).animate({'bottom': -100}, 1000);
		// jQuery('#logo').css('display', 'none').fadeIn(1000);

	}	
}

