Drupal.behaviors.init = {
	attach: function (context, settings) {
		

		// SERVICE LINKS TOGGLE
		jQuery('.footer .share h3').click(function(){

			jQuery(this).next().slideToggle();
			return false;

		});

		// COMMENT FORM
		jQuery('.add-comment-btn').click(function(){
			jQuery('.comment-form-holder').slideToggle();
		});
			

		// MOBILE STUFF
		jQuery('.menu-toggle').click(function(){
			jQuery('#nav').stop(false, true).slideToggle();
		});

		jQuery(window).resize(function(){

			windowResized();
		});


		function windowResized(){
			
			var win_w = jQuery(window).width();
			var win_h = jQuery(window).height();

			if(win_w < 700){
				jQuery('body').addClass('mobile');
			}else{
				jQuery('body').removeClass('mobile');
			}

			//console.log(win_w);
		}

		windowResized();
	}
}

Drupal.behaviors.pinit = {
	attach: function (context, settings) {
			
			jQuery('.image-post_full').after('<div class="hover-pinterest"><a class="pin-it-link" target="_blank"></a></div>').parent().addClass('image-holder');
			jQuery('.image-holder').hover(
				function() {

					var pinit = jQuery('.hover-pinterest', this);
					var pinita = jQuery('.hover-pinterest a', this);
					var image = jQuery('.image-post_full', this);
					var imgurl = image.attr('src');
					var encodedurl = encodeURIComponent(imgurl);
					var pathname = jQuery(location).attr('href');
					var url = encodeURIComponent(pathname);
					var desc = encodeURIComponent('');
					var pinhref = 'http://pinterest.com/pin/create/button/?url=';
					pinhref += url;
					pinhref += '&media=';
					pinhref += encodedurl;
					pinhref += '&description=';
					pinhref += desc;
					pinita.attr('href', pinhref);
					
					pinit.css('display','block');
					
				},function() {
					//var pinit = jQuery(this).next();
					jQuery('.hover-pinterest', this).css('display','none');
				});
	
	}
}

